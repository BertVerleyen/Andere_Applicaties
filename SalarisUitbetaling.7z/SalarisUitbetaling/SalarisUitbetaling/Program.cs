﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalarisUitbetaling
{
    class Program
    {
        static void Main(string[] args)
        {
            int huidigJaar = 2017;
            SalesStaff controller = new SalesStaff();
           
           IDictionary<string,DateTime> csvdata = new Dictionary<string,DateTime>();

            DateTime date1;
            DateTime date2;
            
        
            for(int i=1;i<=12;i++)
            {
              date1 = new DateTime(huidigJaar, i, 15);//15th of the month
         
     
              date2 = new DateTime(huidigJaar, i, DateTime.DaysInMonth(huidigJaar, i)); //lastdaymonth


            
              
                csvdata = controller.PaymentDatesYear(date1, date2);
                controller.writeCSVFile("C:/salarypaymentDaysMonths.csv",csvdata);
             

            }

            
        
            

        }
    }
}
