﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalarisUitbetaling
{
    class SalesStaff
    {
        private IDictionary<string,DateTime> result = new Dictionary<string,DateTime>();
        private IList<string> keysList = new List<string>();

        public IDictionary<string,DateTime> PaymentDatesYear(DateTime fifteenthDayMonth, DateTime lastDay)
        {

            
                /********************lastdayofmonth=>salary******************************/
              if (lastDay.ToString("dddd") =="zaterdag")
              {
                Console.WriteLine("salary can't be paid on " + lastDay.ToString("dddd"));

                Console.WriteLine("but instead  ...");

                DateTime beforeWeekend = lastDay.AddDays(-1);
                Console.WriteLine("salary will be paid on " + beforeWeekend);
                Console.ReadLine();
                result["SalaryPayDate"] = beforeWeekend;

                
               }


               else if (lastDay.ToString("dddd") == "zondag")
               {
                Console.WriteLine("salary can't be paid on " + lastDay.ToString("dddd"));
                Console.WriteLine("but instead  ...");

                DateTime beforeWeekend = lastDay.AddDays(-2);
                Console.WriteLine("salary will be paid on " + beforeWeekend );
                Console.ReadLine();
                result["SalaryPayDate"] = beforeWeekend;
                }


                else
                {
                Console.WriteLine("salary will definitely be paid on " + lastDay);
                result["SalaryPayDate"] = lastDay;
                }
              
                /***************************fifteenthofmonth=> bonus*************************/
              if (fifteenthDayMonth.ToString("dddd").Equals("zaterdag"))
              {
                  Console.WriteLine("bonus can't be paid on " + fifteenthDayMonth.ToString("dddd"));
                  Console.WriteLine("but instead  ...");

                  DateTime wedfifteenth = fifteenthDayMonth.AddDays(4);
                  Console.WriteLine("bonus will be paid on " + wedfifteenth);
                  Console.ReadLine();
                  result["BonusPayDate"] = wedfifteenth;


              }


              else if (fifteenthDayMonth.ToString("dddd") == "zondag")
              {
                  Console.WriteLine("bonus can't be paid on " + fifteenthDayMonth.ToString("dddd"));
                  Console.WriteLine("but instead  ...");

                  DateTime wedfifteenth = fifteenthDayMonth.AddDays(3);
                  Console.WriteLine("bonus will be paid on " + wedfifteenth);
                  Console.ReadLine();
                  result["BonusPayDate"] = wedfifteenth;
              }


              else
              {
                  Console.WriteLine("bonus will definitely be paid on " + fifteenthDayMonth);
                  Console.ReadLine();
                  result["BonusPayDate"] = fifteenthDayMonth;
              }
            

            return result;

        }

        public void writeCSVFile(string filePath,IDictionary<string,DateTime> csvdata)
        {
           var csv = new StringBuilder();
           

           foreach (var key in csvdata.Keys.Distinct())
           {

               if (!keysList.Contains(key))
               {
                   keysList.Add(key);
                   var columnname = string.Format("{0} \t \t \t \t \t \t \t \t", key);
                   csv.Append(columnname);
               }
               else
               {
                   break;
               }
           }

          
           
           csv.Append(Environment.NewLine);
           csv.AppendLine("-----------------------------------------");
           csv.Append(Environment.NewLine);
           foreach (var m in csvdata.Values)
           {
               
               var rowValues = string.Format("{0}",m);
               
               csv.Append(rowValues+"\t \t \t \t \t \t \t \t");
               
           }
           File.AppendAllText(filePath, csv.ToString());
        }

    }
}
